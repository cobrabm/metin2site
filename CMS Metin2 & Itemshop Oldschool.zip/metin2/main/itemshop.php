<body background="img/form-bg.jpg">
<?php
	header('location: itemshop');
	exit;
?>
</body>
