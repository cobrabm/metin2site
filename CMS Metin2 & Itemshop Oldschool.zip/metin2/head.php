<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Metin2 - Keleti Akció MMORPG</title>
<meta name="description" content="Metin2 - Keleti Akció MMORPG" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/all.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/plugins.css" rel="stylesheet" type="text/css" media="screen"/>
<script type="text/javascript" src="css/js/iepngfix_tilebg.js"></script>
<script type="text/javascript" src="css/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="css/js/jquery.tools.min.js"></script>
<script type="text/javascript" src="./fancybox/jquery.mousewheel-3.0.2.pack.js"></script>
<script type="text/javascript" src="./fancybox/jquery.fancybox-1.3.1.js"></script>
<link rel="stylesheet" type="text/css" href="./fancybox/jquery.fancybox-1.3.1.css" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		var fOptions = {
		 'width'		  : 740,
		 'height'		: 550,
		 'scrolling'		: 'yes',
		 'opacity'		: false,
		 'autoScale'		: true,
		 'transitionIn'	 : 'none',
		 'transitionOut'	 : 'none',
		 'type'		  : 'iframe'
		};
		$("#various2").fancybox(fOptions);
		$("#various3").fancybox(fOptions);
		$("#various4").fancybox(fOptions);
	});
</script>
