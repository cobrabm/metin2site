<div class="modul-box">
	<div class="modul-box-bg">
		<div class="modul-box-bg-bottom">
			<h3>Belépés</h3>
			<form action="?s=login" method="post">
				<div class="form-login">
					<label> Felhasználónév:</label>
					<div class="input">
						<input type="text" name="user" required /><br />
					</div>
					<label> Jelszó:</label>
					<div class="input">
						<input type="password" name="pw" required /><br />
					</div>
					<div>
						<input type="submit" class="button btn-login" name="login" value="Login">
						<p class="agbok">
						A belépéssel elfogadod a <a href="imprint.html" target="_blank"><strong>felhasználási feltételeket</strong></a> .	
						<a href="?s=passwordlost" class="password">Elfelejtett jelszó?</a>
						</p>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
