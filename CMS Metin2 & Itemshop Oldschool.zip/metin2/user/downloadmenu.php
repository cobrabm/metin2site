<div class="header-box">
	<div id="regBtn"> 
		<a id="toReg" href="?s=register" title="Regisztrálj és töltsd le a Metin2-t most!">Regisztrálj és töltsd le a Metin2-t most!</a>
		<div id="regSteps">
			<a href="?s=register" title="1. Regisztráció   »   2. Letöltés és telepítés   »   3. Játssz a Metin2-vel!"><span>1. Regisztráció   »   2. Letöltés és telepítés   »   3. Játssz a Metin2-vel!</span></a>
		</div>
	</div>
</div>
<script type="text/javascript">
	$('#regBtn').hover(
	  function () {
		$(this).addClass("reg-hover");
	  },
	  function () {
		$(this).removeClass("reg-hover");
	  }
	);
</script>
