<div class="center">
	<div id="userBox">
		<br />
		<ul class="header-box-nav-login" style="margin-left:15px;">
			<li class="stepdown"><a id='various4' href="?s=itemshop" class="nav-box-btn nav-box-btn-1">ItemShop</a></li>
			<li class="stepdown"><a href="?s=profil" class="nav-box-btn nav-box-btn-2">Felhasználó</a></li>
			<li class="stepdown"><a href="?s=logout" class="nav-box-btn nav-box-btn-4">Kilépés</a></li>
		</ul>
	</div>
</div>
