<meta charset="UTF-8">
<link rel="icon" href="favicon.ico" type="image/x-icon" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>Item-Shop</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/start.css" rel="stylesheet" type="text/css" />
<link href="css/options.css" rel="stylesheet" type="text/css" />
<link href="css/discount.css" rel="stylesheet" type="text/css" />
<link href="css/tiptip.css" rel="stylesheet" type="text/css" />
<link href="css/fancybox.css" rel="stylesheet" type="text/css" />
<link href="css/jScrollPane.css" rel="stylesheet" type="text/css" />
<link href="css/promoted.css" rel="stylesheet" type="text/css" />
<!-- <link href="css/pending.css" rel="stylesheet" type="text/css" /> -->
<link href="css/usermenu.css" rel="stylesheet" type="text/css" />
<link href="css/purchase.css" rel="stylesheet" type="text/css" />
<link href="css/wheel.css" rel="stylesheet" type="text/css" />
<!--[if IE]>
<style type="text/css">@import url(css/6ea1bf4927ebc189a9ad0a0e2d7140.css);</style>
<style type="text/css">@import url(css/8a0cdb2c5a2e9c5af58e1dcdee50e7.css);</style>
<![endif]-->
<!--[if lte IE 6]>
<style type="text/css">@import url(css/5338b6f852df99e7b508f046cc25ad.css);</style>
<style type="text/css">@import url(css/f0c4e2637ede70860c1a273ed38241.css);</style>
<style type="text/css">@import url(css/97c61e083f066422a1ccf00b7e6a02.css);</style>
<![endif]-->
<script type="text/javascript" src="js/b5150cf60c980d685b66eb5826dc1d.js"></script>
<script type="text/javascript" src="js/521e7b8821399457f8d2c96bd4d764.js"></script>
<script type="text/javascript" src="js/7ef645db9fe9c2161d57e2a9684f8c.js"></script>
<script type="text/javascript" src="js/74a2472b07741e6900b40d529efc36.js"></script>
<script type="text/javascript" src="js/c121d2d644f8b6d54b747e69dc319c.js"></script>
<script type="text/javascript" src="js/7b66d958092f8cc1e863c2880d8da6.js"></script>
<script type="text/javascript" src="js/497adc02ec310555ca02b97c5e5b8a.js"></script>
<script type="text/javascript" src="js/06fa17217edda4ff4898e5e9c27303.js"></script>
<script type="text/javascript" src="js/ae1c0d191bffe28d878d7ec7062da2.js"></script>
