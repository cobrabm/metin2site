<!DOCTYPE html>
<html>
	<head>
		<style>
			body {
				background-image:url(img/frame_bg.jpg);
			} 
			iframe {
				margin-top: 5%;
			}
		</style>
		<link rel="icon" href="favicon.ico" type="image/x-icon" />
		<title>Item-Shop</title>
	</head>
	<body>
		<center>
			<iframe src="" width="740" height="550"></iframe>
		</center>
	</body>
</html>