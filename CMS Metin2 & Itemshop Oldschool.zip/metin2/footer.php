<div class="footer-wrapper">
	<div id="footer">
		<a class="gameforge4d" > </a>
		 <ul>
			<li class="first">Copyright © 2010 Metin2.</br>All rights reserved.</li>
		</ul>
	</div>
</div>

<div id="lbBottomContainer" style="display: none;">
	<div id="lbBottom"></div>
	<a id="lbCloseLink" href="#"></a>
	<div id="lbCaption">
		<div id="lbNumber">
			<div style="clear: both;"></div>
		</div>
	</div>
</div>
<div class="simple_overlay" id="gallery"> <a class="back">back</a> <a class="forward">forward</a> <img class="progress" src="https://web.archive.org/web/20100819130254im_/http://static.flowplayer.org/tools/img/overlay/loading.gif"/> </div>
<div class="overlay" id="overlay"> 
    <div class="contentWrap"></div> 
</div>
<div style="display: none;">
		</div>


