This is a working replica of the old Metin2 website and ItemShop.
The project originally made in 2013 for a possible server but we never opened it.
For now I just refactored it to be compatible with PHP7/8, tidied the code a little but
honestly, expect real old shit procedural style code! While you can use "as is", I highly 
recommend to check it for old vulnerabilities before you take it live because of it's deprecated nature.
The language is hungarian, you can use web.archive.org to speed up your translation.

Regards,
TMP4